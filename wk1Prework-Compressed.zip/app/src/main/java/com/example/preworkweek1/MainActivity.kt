package com.example.preworkweek1

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import preWorkWK1.button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
//        now access the views created
        val button = findViewById<button>(R.id.submitButton)
        button.setOnClickListener {
//            the action taken when the button is clicked

        }
    // The video syntax is not working
    // here is a screenshot of what i'm seeing
    // please copy and paste link | https://drive.google.com/drive/folders/1NmtxuSelsm721ab5vgwTMxyJGIPEqxzD?usp=sharing
    }
}